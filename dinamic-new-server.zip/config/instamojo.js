const config = {
    purpose: 'DiNAMIC online payment.',
    // api_key: 'c2126af2c6aa6a3f39a05ffda1e320a7', // Live api_key
    api_key: 'e68cfead7609118ee949d2eb464f3589',
    // auth_key: 'edb4fe7f3f46824a94cbe6a96a9165c8', // Live auth_key
    auth_key: 'fe08460e6ea60f15bb2fa8e37d6e2f15',
    redirect_url: 'http://localhost:4200/#/checkout/payment-confirm'
    // redirect_url: 'https://care.dinamic.io/#/checkout/payment-confirm'
};

module.exports = config;