const config = {
	// host: "mail.whitemastery.com",
	// username: "support@dinamic.io",
	// password: "Welcome@1",
	// send_from: "DiNAMIC <support@dinamic.io>",
	// c_username:"support@castemo.com",
	// c_password:"Welcome*1",
	// c_send_from:"support@castemo.com"
	host: "lin.ezveb.com",
	username: "no-reply@dinamic.io",
	password: "Welcome@137",
	send_from: "DiNAMIC <no-reply@dinamic.io>",
}

module.exports = config;