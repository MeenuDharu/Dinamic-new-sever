const mongoose = require('mongoose');

const themeSchema = new mongoose.Schema({    
    theme: {
        pos_rest_id: { type: String },
        isDefaultTheme: { type: Boolean },
        navbarColor: { type: String },
        navbarText: { type: String },
        primaryButtonColor: { type: String },
        primaryButtonText: { type: String },
        secondaryButtonColor: { type: String },
        secondaryButtonText: { type: String },
        disabledButtonColor: { type: String },
        disabledButtonText: { type: String },
        spinnerColor: { type: String },
    },
    homepage: {
        pos_rest_id: { type: String },
        isDefaultHomepage: { type: Boolean },
        header: { type: String },
        subHeader: { type: String },
        headerStatus: { type: Boolean },
        billHeader: { type: String },
        billSubheader: { type: String },
        billImage: { type: String },
        billStatus: { type: Boolean },
        helpHeader: { type: String },
        helpSubheader: { type: String },
        helpImage: { type: String },
        helpStatus: { type: Boolean },
        vehicleHeader: { type: String },
        vehicleSubheader: { type: String },
        vehicleImage: { type: String },
        vehicleStatus: { type: Boolean },
        offerHeader: { type: String },
        offerSubheader: { type: String },
        offerImage: { type: String },
        offerStatus: { type: Boolean },
        exitHeader: { type: String },
        exitSubheader: { type: String },
        exitImage: { type: String },
        exitStatus: { type: Boolean },
    },
    isDefault: { type: Boolean },
    pos_rest_id: { type: String },
    created_on: { type: Date, 'default': Date.now }
})

module.exports = mongoose.model('themes', themeSchema);